<h1 align="center">🔥 MALING KONTOL 🔥</h1>
<p align="center">
  <b>KODE ITU DIBUAT/DIKEMBANGKAN!!<br>
  BUKAN UNTUK DIAMBIL, LALU DIBANGGAKAN!!</b>
</p>

---

<div align="center">
  <h2><b>⛔️ MELARANG KERAS BAGI PELAKU PENCURIAN ⛔️</b></h2>
  <p>Jika Anda menggunakan kode ini tanpa izin dan mengklaimnya sebagai milik Anda, berarti Anda tidak hanya melanggar etika, tetapi juga mempermalukan diri Anda sendiri!</p>
  
  <h3>💀 Kami Percaya Pada Kreativitas, Bukan Pencurian! 💀</h3>
  
  <hr>

  <h2><b>🌟 Jangan Jadi Pecundang! 🌟</b></h2>
  <ul>
    <li><b>Ingin menggunakan kode? Beri kredit kepada pengembang aslinya!</b></li>
    <li><b>Ingin belajar? Tanyakan dengan baik, dan kami akan berbagi!</b></li>
    <li><b>Maling adalah dosa besar di dunia coding.</b></li>
  </ul>
  
  <hr>
  
  <h3>💡 Sumber Kode Kami:</h3>
  <a href="https://t.me/projectnih" target="_blank">
    <img src="https://img.shields.io/badge/Source_Code-Telegram-blue?style=for-the-badge&logo=telegram">
  </a>
</div>

---

<h2 align="center">📢 PERINGATAN KHUSUS</h2>
<p align="center">
  <b>Kami tidak segan untuk mengambil tindakan terhadap siapapun yang mencuri karya ini.<br>Hargai usaha, kreativitas, dan waktu yang dihabiskan untuk membuat karya ini!</b>
</p>

---

<div align="center">
  <h3>👊 JANGAN MALU JADI ORANG JUJUR 👊</h3>
  <p>Orang jujur dihormati.<br> Maling hanya dihina.</p>
  
  <hr>

  <img src="https://files.catbox.moe/p69cg0.jpg" alt="No Stealing" width="400px">
</div>
