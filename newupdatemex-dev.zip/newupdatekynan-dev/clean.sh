rm -rf extracted_db font-module *.jpg *png *raw *session* __pycache__ *tmp* downloads/* log-restart.txt *mp3 *mp4 *unknown* *errors* output/* tmp/* *.zip *.webm unknown_errors.txt
ls