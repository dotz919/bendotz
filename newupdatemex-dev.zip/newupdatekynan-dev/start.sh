#!/bin/bash

python3 src.py