from command import help_cmd
from helpers import CMD


@CMD.UBOT("help")
async def _(client, message):
    return await help_cmd(client, message)
