__MODULES__ = "Format"
__HELP__ = "<blockquote>**To view markdown format please click on the button below.**</blockquote>"

IS_BASIC = True
