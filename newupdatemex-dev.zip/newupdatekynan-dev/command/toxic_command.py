import asyncio

from config import DEVS
from helpers import Message


async def toxic_cmd(client, message):
    command = message.command[0]
    if command == "ngentot":
        await message.reply("**WOYY NGENTOD!!**")
        await asyncio.sleep(3)
        await message.edit("**JANGAN SOK JAGOAN DAH LU**")
        await asyncio.sleep(3)
        await message.edit("**MUKA MASIH KAYA KONTOL AJA**")
        await asyncio.sleep(3)
        await message.edit("**BANGGA LU HAHAHAHA**")
        await asyncio.sleep(3)
        await message.edit("**COBA DEH NGACA MUKA LU KAN HINA BANGET**")
        await asyncio.sleep(13)
        await message.edit("**HAHAHAHA**")
        await asyncio.sleep(3)
        await message.edit("**MAKANYA GANTENG KONTOL**")
        await asyncio.sleep(3)
        await message.edit("**BIAR MUKALU GAK DIHINA TERUS**")
        await asyncio.sleep(3)
        await message.edit("**SAMA ORANG LAIN**")
        await asyncio.sleep(3)
        return await message.edit("**HAHAHAHA**")
    elif command == "ngatain":
        await message.reply("**BABI!!**")
        await asyncio.sleep(3)
        await message.edit("**MUKA LU KAYA BABI**")
        await asyncio.sleep(3)
        await message.edit("**OTAK LU TUH KAYA KONTOL**")
        await asyncio.sleep(3)
        await message.edit("**MUKA LU HINA BANGET**")
        await asyncio.sleep(3)
        await message.edit("**OTAK LU KAYA BATU**")
        await asyncio.sleep(3)
        await message.edit("**HAHAHAHA**")
        await asyncio.sleep(3)
        await message.edit("**MAKANYA JANGAN SANGEAN MULU**")
        await asyncio.sleep(3)
        await message.edit("**KONTOL LU AJA MASIH BENGKOK**")
        await asyncio.sleep(3)
        await message.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
        await asyncio.sleep(1)
        return await message.edit("**HAHAHAHA**")
    elif command == "goblok":
        await message.reply("**WOYY GOBLOK!!**")
        await asyncio.sleep(3)
        await message.edit("**KO LU GOBLOK BANGET SIH**")
        await asyncio.sleep(3)
        await message.edit("**OTAK LU TUH KAYA KONTOL**")
        await asyncio.sleep(3)
        await message.edit("**YANG LEMBEK KETIKA LEMAH**")
        await asyncio.sleep(3)
        await message.edit("**DAN KERAS KETIKA LU SANGE GOBLOK**")
        await asyncio.sleep(3)
        await message.edit("**HAHAHAHA**")
        await asyncio.sleep(3)
        await message.edit("**MAKANYA JANGAN SANGEAN MULU**")
        await asyncio.sleep(3)
        await message.edit("**MUKA LU AJA KAYA ASPAL JALANAN**")
        await asyncio.sleep(3)
        await message.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
        await asyncio.sleep(3)
        return await message.edit("**HAHAHAHA**")
    elif command == "yatim":
        await message.reply("`Hai Anak Kontol 🙈, Jangan Lupa Makan Yaa`")
        await asyncio.sleep(3)
        await message.edit("`Jangan Bilang Lu Ga Dikasih Makan Sama Ortu 😁`")
        await asyncio.sleep(3)
        await message.edit("`APA PERLU GUA SANTUNIN ?? 🙈🙈 xixixi`")
        await asyncio.sleep(3)
        await message.edit("`OH IYAA LUPAAA, LU KAN BEBAN KELUARGA 🤣`")
        await asyncio.sleep(3)
        await message.edit("`MANA MUNGKIN ORTU LU PEDULII xixixi 🙈`")
        await asyncio.sleep(3)
        await message.edit("`KETAWA DULU BOLEH KALI YAA 😁`")
        await asyncio.sleep(3)
        await message.edit("`HAHAHAHAHAHAHA`")
        await asyncio.sleep(3)
        await message.edit("`KASIAN ORTUNYAA GAPEDULIII 🙈🤣`")
        await asyncio.sleep(3)
        await message.edit("`MAAF YA, CANDAA BEBANNNN xixixi 🙈`")
        await asyncio.sleep(3)
        return await message.edit("`Tapi Bo'ong Hiyahiyahiya`")
    elif command == "hina":
        await message.reply("**IZIN PANTUN BANG...**")
        await asyncio.sleep(1.8)
        await message.edit("**KETEMU SI MAMAS DIAJAKIN KE CIBINONG...**")
        await asyncio.sleep(1.8)
        await message.edit("**PULANG NYE DIANTERIN MAKE KOPAJA...**")
        await asyncio.sleep(1.8)
        await message.edit("**EH BOCAH AMPAS TITISAN DAJJAL...**")
        await asyncio.sleep(1.8)
        await message.edit("**MUKA HINA KEK ODONG ODONG**")
        await asyncio.sleep(1.8)
        await message.edit(
            "**GA USAH SO KERAS DEH LU KALO MENTAL BLOM SEKERAS BAJA...**"
        )
        await asyncio.sleep(1.8)
        await message.edit("**LUH ITU MANUSIA...**")
        await asyncio.sleep(1.8)
        await message.edit("**MANUSIA HINA YANG DI CIPTAKAN DENGAN SECARA HINA**")
        await asyncio.sleep(1.8)
        return await message.edit(
            "**MANUSIA HINA YANG DI CIPTAKAN DENGAN SECARA HINA EMANG PANTES UNTUK DI HINA HINA...**"
        )
    elif command == "alay":
        await message.reply("**Eh Kamu Ganteng-ganteng**")
        await asyncio.sleep(1.8)
        await message.edit("**Kok Alay Banget**")
        await asyncio.sleep(1.8)
        await message.edit("**Spam Bot Mulu**")
        await asyncio.sleep(1.8)
        await message.edit("**Baru Bikin Userbot Ya??**")
        await asyncio.sleep(1.8)
        return await message.edit("**Pantes Norak Xixixi**")
    elif command == "ngaca":
        await message.reply("**IZIN NUMPANG PANTUN BANG...**")
        await asyncio.sleep(1.8)
        await message.edit("**BELI SEPATU KACA KE CHINA...**")
        await asyncio.sleep(1.8)
        await message.edit("**ASEEEKKKK 🤪**")
        await asyncio.sleep(1.8)
        await message.edit("**NGACA DULU BARU NGEHINA KONTOL...**")
        await asyncio.sleep(1.8)
        await message.edit(
            "**UDAH BULUK ITEM PENDEK BERPONI BAJU KEGEDEAN KAYAK JAMET**"
        )
        await asyncio.sleep(1.8)
        await message.edit("**UDAH BULUK ITEM SOK-SOK AN MAU NGEHINA GUA KONTOL**")
        await asyncio.sleep(1.8)
        return await message.edit("**KENA KAN MENTAL LU...**")
    elif command == "kontol":
        await message.reply("**LU KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**LU ANAK KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**DI BIKIN DARI KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**MUKALU PERSIS KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**DASAR ANAK NGONTOLLLL**")
        await asyncio.sleep(2.5)
        await message.edit("**NOLEP KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**NGERUSUH KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**BENER BENER KONTOL**")
        await asyncio.sleep(2.5)
        await message.edit("**PADAHAL LO GAPUNYA KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**MENDING LO OPERASI KONTOLL**")
        await asyncio.sleep(2.5)
        await message.edit("**BIAR LO PUNYA KONTOLL**")
        await asyncio.sleep(2.5)
        return await message.edit("**KASIAN CACAD GAPUNYA KONTOLL**")


async def alfabet_cmd(client, message):
    if message.reply_to_message and message.reply_to_message.from_user.id in DEVS:
        return await message.reply("**AKUN LO MO ILANG BANGSAT??**")
    command = message.command[0]
    if command == "a":
        await message.reply(
            "**ANAK KONTOL, MUKA KEK JEMBUT MASIH MAEN TELE ?**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "b":
        await message.reply(
            "**BAJINGAN!! KEREN LOE GITU ? CUIH ANAK HASIL CLONE BELAGU**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "c":
        await message.reply(
            "**CEBOK LAH DEK MINIMAL SEBELUM TYPING!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "d":
        await message.reply(
            "**DARI KEMAREN GW LIATIN MUKA LU KAGA BENER-BENER!! KEBENGKEL LAS DULU SONO. TAMBEL ITU MUKA LOE YANH BOPAK**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "e":
        await message.reply(
            "**EALAH INI TOH PETINGGI TELE ? JUJURLY MUKA LU KEK JAMET PASAR SENEN BANG. MENDING LOE NGADUK SEMEN!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "f":
        await message.reply(
            "**FANTAT LOE BURIK YA ? SOALNYA MUKA LU KEREMIAN!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "g":
        await message.reply(
            "**GOBLOK DIPIARA!! MEMEG NOH LOE PIARA BIAR BANYAK ANAK!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "h":
        await message.reply(
            "**HAHAHAHA KOK DIEM ? BINGUNG YA LOE BACOT APAAN**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "i":
        await message.reply(
            "**IDIH NAJIS BET PESAN GW DIREP AMA BOCAH KEK LOE**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "j":
        await message.reply(
            "**JEMBUT LOE DAH DICUCI BELOM SI ? KOK BAU JEMBUT INI YA??**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "k":
        await message.reply(
            "**KALO TYPING YANG BENER DEK!! POTRET BOCAH KAGA PERNAH MAKAN PAPAN TULIS SEKOLAH AN**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "l":
        await message.reply(
            "**LAGI NGAPA BAE SI BOCAH ?? ETT DAH GW BANTING, GW GEDIK, GW BANDUT MATI LOE!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "m":
        await message.reply(
            "**MEMEG EMA LO BURIK YA ? MUKA LO ITU KAYA DAKI MULU KAYA PINGGIRAN PANTAT BANYAK TAI KERING**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "n":
        await message.reply(
            "**NETE DULU SONO BARU NGEBACOT, LAA BOCAH NGOMONG KEK SAMBIL MAKAN PASIR. MANA TAI KUCING MULU!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "o":
        await message.reply(
            "**OHHH INI ORANG NYA? YANG SUKA NYOLONG ? PENGAMGGURAN ? MAKAN DUIT HARAM ? NGENTOT TIAP HARI ? BAHAHAHHA ORA PANTES BET MUKA-MUKA BOCAH AUTIS**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "p":
        await message.reply(
            "**P for peler, MEMEK**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "r":
        await message.reply(
            "**RAME AMAT YA, KEREN KALI MAH BEGITU? LAA BOCAH BARU LAHIR KEMAREN BANYAK GAYA. TONG TONG!! EMA LO NYESEL KEK NYA LAHIRIN MAKHLUK KE LU!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "s":
        await message.reply(
            "**SIAPA ? EMA LU SIAPA ? KAGA MIRIP EMA AMA BABA LU. ANAK BOLEH MUNGUT DI PINGGIR GOT KALI LU!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "t":
        await message.reply(
            "**TUMAN, BOCAH TUMAN. DIKASIH PANGGUNA LANTAS BAE BERTINGKAH. MENDING CAKEP LA MUKA KAYA PANTAT PENGAMEN KAGA MANDI 1 MINGGU**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "u":
        await message.reply(
            "**UNTUNG GW BUKAN TEMEN NYA DIA, BUNUH BAE MAKHLUK KAYA GINI. EMANYA JUGA IKHLAS KALI DIA MATI!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "v":
        await message.reply(
            "**APA KONTOL?**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "w":
        await message.reply(
            "**WAH BAJINGAN INI LAMA LAMA KAYA JEMBUT, GA BENER BENTUKNYA!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "x":
        await message.reply(
            "**DIEM MEMEG, MUKA JERAWATN BANYAK BACOT LU!!**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    elif command == "z":
        await message.reply(
            "**DIEM BANGSAT, BACOT MULU DARI KEMAREN. JADI BEBAN DOANG BELAGU LU. GAWE TONG GAWE, LAA PUNYA AKAL SI DIDIEMIN KAGA DIPAKE**",
            reply_to_message_id=Message.ReplyCheck(message),
        )
    return await message.delete()
